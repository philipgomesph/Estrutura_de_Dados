#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

int main()
{
    Cria_fila();
    return 0;
}
