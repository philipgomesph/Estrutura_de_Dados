#include <stdio.h>
#include <stdlib.h>
#define max 10




int main()
{



    return 0;
}


///criando a estrutura

struct pilha{
    int tamanho[max];
    int topo;
};
typedef struct pilha *Pilha;


///Criando a pilha alocando o tamanhao do espaco do tamanho da estrutura

Pilha cria_pilha(){
   Pilha Ptp;
   Ptp = (Pilha) malloc(sizeof(struct pilha));
   if(Ptp != NULL)
        Ptp->topo = -1;
   return Ptp;
}

///Verificando se a pilha esta cheia
int E_cheia(Pilha Ptp){
    if(Ptp->topo == max-1)
        return 1;
    else
        return 0;

}

///Verificando se a pilha esta vazia
int E_vazia(Pilha Ptp){
    if(Ptp->topo == -1)
        return 1;
    else
        return 0;
}

///Inserir elemento na pilha
int Push(Pilha *Ptp, int elem){
    if((*Ptp)->topo == max-1)
        return 0;

        ///*Ptp == local
    (*Ptp)->topo++;

        ///pegando o local e escrevendo dentro dele
    (*Ptp)->tamanho[(*Ptp)->topo]=elem;

    return 1;
}


int* Pop(Pilha *Ptp){
    int* elem;

    if((*Ptp)->topo == -1)
        return NULL;+.
    ///"APAGANDO", criando espa�o em cima do elementro escrito.
    elem = (int*)malloc(sizeof(int));
    *elem = (*Ptp)->tamanho[(*Ptp)->topo];

    ///Mudando quem � o topo
    (*Ptp)->topo--;
    return elem;
}

