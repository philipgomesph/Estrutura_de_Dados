#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int dado;
    struct no *esq;
    struct no *dir;
}no;

no *raiz;
no *atual;
no *ant;

void cria_arvore()
{
    raiz=NULL;
    atual=NULL;
    ant=NULL;

}

int insere_arvore(int valor)
{
    ///CRIA NO
    no *novo;
    novo = (no*)malloc(sizeof(no));
    novo->dado=valor;
    novo->dir=NULL;
    novo->esq=NULL;

    ///VERIFICA ONDE INSERIR
    if(raiz==NULL)
    {
        ///SE FOR A PRIMEIRA VEZ
        raiz=novo;
        return 1;
    }else
    {
        atual=raiz;
        ant=atual;
        while(atual!=NULL)
        {
            if(valor>atual->dado)
            {
                ant=atual;
                atual=atual->dir;
            }else
            {
                ant=atual;
                atual=atual->esq;
            }
        }

        ///INSERE COMO FILHO DESSA FOLHA
        if(valor>ant->dado)
        {
            ant->dir = novo;
        }else
        {
            ant->esq = novo;
        }
        return 1;
    }
}
///PRINTAR A ARVORES
int menu()
{
    int opc;
    system("CLS");
    printf("\n\t~~  MENU  ~~");
    printf("\n1 - Inserir na Arvore ");
    printf("\n2 - Remover na Arvore ");
    printf("\n3 - Mostrar Arvore pre_order ");
    printf("\n4 - Mostrar Arvore in_order ");
    printf("\n5 - Mostrar Arvore pos_order");
    printf("\n0 - Sair.\n->");
    scanf("%d",&opc);
    while(opc <0 || opc >5)
    {
        printf("\nOPC invalida, digite novamente...");
        scanf("%d",&opc);
    }
    return opc;
}
int main()
{
    int opc,valor;

    opc = menu();
    while(opc!=0)
    {
        switch(opc)
        {
        case 1:
            system("CLS");
            printf("\n\tDIGITE VALOR A SER INSERIDO:\n->");
            scanf("%d",&valor);

            valor = insere_arvore(valor);
            opc = menu();

            break;
        case 2:
            system("CLS");
            printf("\nAINDA NAO IMPLEMENTADO ....\n");
            system("pause");
            opc = menu();
            break;
        case 3:
            ///PRINTAR EM PRE_ORDEM
            opc = menu();
            break;
        case 4:
            ///PRINTAR EM EM_ORDEM
            opc = menu();
            break;
        case 5:
            ///PRINTAR EM POS_ORDEM
            opc = menu();
            break;
        }
    }
    printf("\n\n\t AINDA FUNCIONANDO \n");
    return 0;
}
