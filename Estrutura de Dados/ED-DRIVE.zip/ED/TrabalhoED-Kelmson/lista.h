#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct funcionario
{
    int matricula;
    char nome[30];
    float salario;
    struct funcionario *proximo;
};
//assinatura das funcoes usadas.
struct funcionario *inserir (struct funcionario *lista);
void mostrar (struct funcionario *lista);
void maiorNome (struct funcionario *lista);
int verificaMatricula (int numeroMatricula, struct funcionario *lista);

#endif // LISTA_H_INCLUDED
