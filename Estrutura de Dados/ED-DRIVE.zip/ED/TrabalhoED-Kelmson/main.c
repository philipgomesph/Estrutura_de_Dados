#include <stdio.h>
#include <stdlib.h>

int main()
{
    struct funcionario *lista;
    lista = NULL;

    int opcao;
    //Exibi�ao do menu p/ o cliente
    do
    {
        printf ("\n  0 - Sair.\n");
        printf ("  1 - Inserir.\n");
        printf ("  2 - Mostrar.\n");
        printf ("  3 - Buscar nome mais longo.\n");

        scanf ("%i", &opcao);
        //diferentes casos do menu
        switch (opcao)
        {
            case 1:
            {
                lista = inserir(lista);
            } break;

            case 2:
            {
                mostrar (lista);
            } break;

            case 3:
            {
                maiorNome(lista);
            } break;
        }

    } while (opcao != 0);

    printf ("\t\t  Obrigado por usar!\n");

    return 0;
}
