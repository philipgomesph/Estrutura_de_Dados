#include "lista.h"

struct funcionario *inserir (struct funcionario *lista)
{


    int matriculatemp;
    char nometemp[30];
    float salariotemp;

    system ("cls");

    //Inserir dados ns variaveis TEMPORARIAS
    printf ("  Insira o numero de matricula do funcionario: ");
    scanf ("%i", &matriculatemp);
    //Validacao p/ nao permitir matriculas iguais
    while ((verificaMatricula(matriculatemp, lista)) == 0)
    {
        printf ("  Matricula invalida, insira novamente:");
        scanf ("%i", &matriculatemp);
    }

    printf ("  Insira o nome do funcionario: ");
    fflush (stdin);
    gets (nometemp);

    printf ("  Insira o salario do funcionario: ");
    scanf ("%f", &salariotemp);

    //Criar bloco p/ alocar memoria e transferir os dados das variaveis temporarias p/ a lista
    struct funcionario *novo;
    novo = (struct funcionario*) malloc (sizeof  (struct funcionario));

    novo->matricula = matriculatemp;
    novo->salario = salariotemp;
    strcpy (novo->nome, nometemp);
    novo->proximo = NULL;

    //Decidir onde colocar ou n�o os novos dados na lista
    struct funcionario *aux;
    aux = lista;

    if (aux == NULL)
    {
        //apenas p/ lista cheia
        lista = novo;
    }
    else
    {
        //percorrer toda a lista ate o ultimo elemento
        while (aux->proximo != NULL)
        {
            aux = aux->proximo;
        }

        aux->proximo = novo;
    }

    //retornar lista
    return (lista);
};

void mostrar (struct funcionario *lista)
{
    struct funcionario *aux;
    aux = lista;

    while (aux != NULL)
    {
        printf ("  Matricula: %i\n", aux->matricula);
        printf ("  Nome: %s\n", aux->nome);
        printf ("  Salario: R$ %.2f\n\n", aux->salario);

        aux = aux->proximo;
    }
}

void maiorNome (struct funcionario *lista)
{
    char maiorNombre[30];
    struct funcionario *aux;
    aux = lista;

    strcpy(maiorNombre, lista->nome);
    //comparacao do maior nome da lista
    while (aux != NULL)
    {
        if (strlen(aux->nome) > strlen(maiorNombre))
        {
            strcpy(maiorNombre, aux->nome);
        }
        aux = aux->proximo;
    }
    //biblioteca usada p/ achar a posicao do ultimo espa�o para printar o ultimo nome do maior encontrado
    char *last = strrchr(maiorNombre, ' ');

    if (last != NULL) {
        printf("  %s\n", last+1);
    }
}
//Fun�ao p/ validar as entradas das matriculas
int verificaMatricula (int numeroMatricula, struct funcionario *lista)
{
    //0 - N�o inserir
    //1 - Inserir

    struct funcionario *aux;
    aux = lista;

    if (aux == NULL)
    {
        return (1);
    }
    else
    {
        while (aux != NULL)
        {
            if (numeroMatricula == aux->matricula)
            {
                return (0);
            }

            aux = aux->proximo;
        }

        return (1);
    }
}
