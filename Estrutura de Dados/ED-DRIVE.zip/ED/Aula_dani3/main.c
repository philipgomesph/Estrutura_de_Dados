#include <stdio.h>
#include <stdlib.h>


struct pessoa {
    char cpf[11];
    char nome[20];
    char endereco[30];
    char sexo;
    char telefone[15];
    int idade;
    float salario;
    int impostorenda;
};typedef struct pessoa Pessoa;

/*Pessoa receber(pessoas){

int i =0;

    for(i=0;i<30;i++){
            system("cls");
            fflush(stdin);

            printf("Digite os dados da pessoa");

            printf("\nInforme o cpf\n");
            gets(pessoas[i].cpf);

            printf("\nDigte o nome\n)");
            gets(pessoas[i].nome);

            printf("\nDigite o endereco");
            gets(pessoas[i].endereco);

            printf("\nDigite o sexo");
            gets(pessoas[i].sexo);

            printf("\nDigite o telefone");
            gets(pessoas[i].telefone);

            printf("\nDigite a idade");
            get(pessoas[i].idade);

            printf("\nDigite o salario");
            get(pessoas[i].salario);

            printf("\nDeclare o imposto de renda");
            get(pessoas[i].impostorenda);
}
*/


int main()
{
    struct pessoa *pessoas;
    int opc=10;
    int i=0;
    pessoas = (Pessoa*) malloc(30*sizeof(Pessoa));


    do{

        printf("   ~~~~ MENU ~~~~");
        printf("\n\nDigite uma opcao abaixo");
        printf("\n1 - Inserir pessoa.");
        printf("\n2 - Mostrar pessoas cadastradas.");
        printf("\n3 - Mostrar pessoas com Imposto de renda acima de 2500");
        printf("\n4 - Mostrar pagamentos do imposto de renda");
        printf("\n0 - Sair.\n");
        scanf("\n%d",&opc);

        switch(opc){


    case 1:{
        for(i=0;i<30;i++){
            system("cls");
            fflush(stdin);

            printf("Digite os dados da pessoa");

            printf("\nInforme o cpf\n");
            gets(pessoas[i].cpf);

            printf("\nDigte o nome\n)");
            gets(pessoas[i].nome);

            printf("\nDigite o endereco");
            gets(pessoas[i].endereco);

            printf("\nDigite o sexo");
            gets(pessoas[i].sexo);

            printf("\nDigite o telefone");
            gets(pessoas[i].telefone);

            printf("\nDigite a idade");
            gets(pessoas[i].idade);

            printf("\nDigite o salario");
            scanf("%f",pessoas[i].salario);

            printf("\nDeclare o imposto de renda");
            gets(pessoas[i].impostorenda);
}
        }


        }


    }while(opc!=0);

    return 0;
}
