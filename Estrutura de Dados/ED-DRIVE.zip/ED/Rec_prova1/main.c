#include <stdio.h>
#include <stdlib.h>
#include "rec.h"

int main()
{

    printf("\n\n\     AINDA FUNCIONANDO\n\n\n");
    return 0;
}
