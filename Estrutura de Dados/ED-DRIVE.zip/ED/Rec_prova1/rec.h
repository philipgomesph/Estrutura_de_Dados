#ifndef REC_H_INCLUDED
#define REC_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

typedef struct no
{
    int data;
    struct no * prox;
    struct no * antes;
}*NO;

typedef struct queue{
    int tamanho;
    NO da_frente;
    NO de_traz;
} *QUEUE;




#endif // REC_H_INCLUDED
