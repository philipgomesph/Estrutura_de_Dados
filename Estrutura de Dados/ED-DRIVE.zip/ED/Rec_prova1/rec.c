#include "rec.h"



///CALLOC = inicia zerado, MALLOC �!!

NO novo_no(int data, NO prox, NO antes){
    NO n = (NO) calloc(1 , sizeof(struct no));
    n->data = data;
    n->prox = NULL;
    n->antes = NULL;
}

QUEUE novo_queue(){
    QUEUE q = (QUEUE) malloc(sizeof(struct queue));
    q->tamanho = 0;
    q->da_frente = (NO) malloc(sizeof(struct no));
    q->de_traz = (NO) malloc(sizeof(struct no));
}

int tamanho(QUEUE q){
    return q->tamanho;
}

int vazio(QUEUE q){
    return tamanho(q) == 0;
}
int mostra_topo(QUEUE q){
    if(vazio(q))
        return -1;
    return q->da_frente->data;
}


