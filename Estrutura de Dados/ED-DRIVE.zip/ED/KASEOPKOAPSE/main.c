#include <stdio.h>
#include <stdlib.h>
#include "pontoH.h"
int main()
{
    //VARIAVES GLOBAIS
    int opc;
    int opcLista;
    opc = menuInicial();
    int opcRecursao;

    //VARIAVEIS LISTA
    struct Pessoa *lista;
    lista = NULL;

    //VARIAVEIS RECURSAO
    int fatorial;
    int soma;

    //desenvolvimento
    while(opc!=0)
    {
        while(opc<0 || opc>3)
        {
            printf("Op�ao invalida, digite novamente\n");
            scanf("%d",&opc);
        }
        switch(opc)
        {
        case 1:
            {
            opcLista = menuLista();
            switch(opcLista)
            {
            case 1:
                lista = inserir(lista);
                break;
            case 2:
                mostrar(lista);
                system("pause");
                break;
            case 3:
                lista = removerInicio(lista);
                break;
            case 4:
                lista = removerFim(lista);
                break;
            case 0:
                opc = menuInicial();
            }
            break;
            }
        case 2:
            {

            opcRecursao = menuRecursao();
            switch(opcRecursao)
            {

            case 1:
                {
                    system("CLS");
                    printf("Digite um numero para saber o fatorial: \n");
                    scanf("%d",&fatorial);

                    fatorial = calculaFatorial(fatorial);
                    printf("Resultado: %d\n\n",fatorial);
                    system("pause");
                }
                break;
            case 2:
                    system("CLS");
                    printf("Digite um numero no qual deseja saber a soma dos numeros anteriores: \n");
                    scanf("%d",&soma);
                    soma = calculaSoma(soma);
                    printf("Resultado:%d\n\n", soma);
                    system("pause");



                break;
            case 3:

                break;
            case 0:
                opc = menuInicial();
                }
            }
                break;
        case 3:
            break;
        default:
            opc = menuInicial();
            break;

        }
    }
    system("CLS");
    printf("OBRIGADO POR USAR NOSSO SISTEMA");
    printf("\n\n\t AINDA FUNFANDO\n");

    return 0;
}

int menuInicial()
{
    int opc;


    printf("\n\n\t  ~~~~  MENU  ~~~~");
    printf("\n1 - Lista");
    printf("\n2 - Recursao");
    printf("\n3 - Lista com prioridade");
    printf("\n0 - Sair.\n");
    scanf("\n%d",&opc);

    return(opc);
}

int menuLista()
{

    int opcLista;

    system("CLS");
    printf("ESCOLHA UMA OPC");
    printf("\n1 - Adicionar membro");
    printf("\n2 - Mostrar membros");
    printf("\n3 - Remover Inicio");
    printf("\n4 - Remover Fim");
    printf("\n0 - Retornar");

    scanf("%d",&opcLista);
     while(opcLista<0 || opcLista > 4)
    {
        printf("OPC invalida, digite novamente\n");
        scanf("%d",&opcLista);

    }
    return (opcLista);
}
int menuRecursao()
{
    int opcRecursao;
    system("CLS");
    printf("ESCOLHA UMA OPC");
    printf("\n1 - Fatorial de um numero");
    printf("\n2 - Soma de numeros anteriores");
    printf("\n3 - exer3");
    printf("\n0 - Sair");
    scanf("%d",&opcRecursao);

    while(opcRecursao<0 || opcRecursao>3)
    {
        printf("Opcao invalida, digite novamente\n");
        scanf("%d",&opcRecursao);
    }
    return opcRecursao;
}

int calculaFatorial(fatorial)
{
    if(fatorial == 0)
    {
        return 1;
    }

    if(0<fatorial)
    {
        fatorial = fatorial*calculaFatorial(fatorial - 1);
    }
    return fatorial;
}
int calculaSoma(soma)
{
    if(soma>=1)
    {
    soma = soma + calculaSoma(soma-1);
    }
    return soma;
}
