#include "pontoH.h"


//DESENVOLVENDO AS FUN�OES

struct Pessoa *inserir (struct Pessoa *lista)
{
    //variaveis temporarias para testes
    char nomeTemp[30];
    int cpfTemp;



    system("CLS");
    printf("Digite os dados\n");
    printf("Nome: ");
    fflush(stdin);
    gets(nomeTemp);
    printf("\nCPF: ");
    scanf("%d",&cpfTemp);
    while(cpfTemp<0 || cpfTemp> 99999)
    {
        printf("\nNumero de cpf invalido, digite novamente");
        scanf("%d",&cpfTemp);
    }

    //Declarando uma estrutura
    struct Pessoa *novo;
    novo = (struct Pessoa*) malloc(sizeof (struct Pessoa));

    novo->cpf = cpfTemp;
    strcpy(novo->nome,nomeTemp);
    novo->prox = NULL;

    //EScolhendo onde colocar na lista
    struct Pessoa *aux;
    aux= lista;

    if(aux == NULL)
    {
        //SE A LISTA ESTIVER VAZIA INSERE
        lista = novo;
    }else
    {
        //La�o para percor a lista
        while(aux->prox!=NULL)
        {
            aux = aux->prox;
        }
        //SE FOR O ULTIMO MEMBRO, INSERE
        aux->prox = novo;
    }
    return(lista);

    };
void mostrar(struct Pessoa *lista)
{
    if(lista == NULL)
    {
       printf("\nLista vazia\n");
       system("pause");
    }
    struct Pessoa *aux;
    aux = lista;

    while(aux!=NULL)
    {

        printf("\nNome: %s\n", aux->nome);
        printf("CPF: %d\n",aux->cpf);

        aux = aux->prox;
    }
}
//REMOVE TOPO
struct Pessoa *removerInicio(struct Pessoa *lista)
{
    if(lista == NULL)
    {
       printf("\nLista vazia");
       system("pause");
    }
    else
    {
        struct Pessoa *aux;
        aux = lista;

        lista = lista->prox;
        free(aux);
    }

return(lista);
};

//nao ta funfando direito

struct Pessoa *removerFim(struct Pessoa *lista)
{
     if(lista == NULL)
    {
       printf("\nLista vazia");
       system("pause");
    }
    else
    {
        struct Pessoa *anterior;
        struct Pessoa *atual;
        anterior = NULL;
        atual = NULL;

        atual = lista;

        while(atual->prox!= NULL)
        {
            //PEGAR NO ANTES DO ULTIMO, ATUAL = ULTIMO nessa linha
            anterior = atual;

            //RODAR a lista
            atual = atual->prox;
        }
        anterior->prox = NULL;
        free(atual);
        lista = anterior;
        return(lista);

    }
};





//EXEMPLOS RECURSAO

/* imprime uma string em ordem reversa*/

/*#include <stdio.h>
#include <conio.h>
void contrario(char s[]) {
 if (s[0] != '
\0'){
 contrario(&s[1]);
 printf("%c",s[0]);} }

int main(void) {
 char s[30],c;
 int t;
 printf("Imprime reverso
\
n
\n");
 printf("
\nDigite a string: ");
 gets(s);
 contrario(s);
 getch(); }


 //conta quantas vezes um caractere ocorre em uma string

#include <stdio.h>
#include <conio.h>
int carac(char c,char s[])
{
 if (s[0] == '\0')
 return 0;
 if (s[0]==c) return (1+carac(c,++s));
 return carac(c,++s);
}

int main(void)
{
 char s[30],c;
 int t;
 printf("Busca em string\n\n");
 printf("\nDigite a string: ");
 gets(s);
 printf("\nDigite o caractere desejado: ");
 c=getchar();
 t=carac(c,s);
 printf("\n\nEncontrei %d vezes", t);
 getch();

*/


