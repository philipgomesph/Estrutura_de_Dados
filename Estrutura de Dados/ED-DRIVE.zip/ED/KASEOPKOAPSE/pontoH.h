#ifndef PONTOH_H_INCLUDED
#define PONTOH_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Pessoa
{
    char nome[30];
    int cpf;
    struct Pessoa *prox;
    struct pessoa *ant;
};

struct Pessoa *inserir (struct Pessoa *lista);
void mostrar(struct Pessoa *lista);
//REMOVE TOPO
struct Pessoa *removerInicio(struct Pessoa *lista);

struct Pessoa *removerFim(struct Pessoa *lista);





#endif // PONTOH_H_INCLUDED
