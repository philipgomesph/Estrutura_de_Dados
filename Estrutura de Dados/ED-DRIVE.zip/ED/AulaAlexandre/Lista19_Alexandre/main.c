#include <stdio.h>
#include <stdlib.h>
#include<stdbool.h>
typedef struct {
 int item;
 struct pilha *ant;
}pilha;

pilha *nova_celula;
pilha *topo;
pilha *valor;

int contador;
void inicializa_pilha(){
    topo=NULL;
    contador =0;
}

bool pilha_vazia(){
    if(topo == NULL){
        return true;
    }else{
        return false;
    }
}
void insere_pilha(){

    int valor;

    system("cls");
    printf("Informe o valor: >_");
    scanf("%d",&valor);

    nova_celula =(pilha *)malloc(sizeof(pilha));

    if(nova_celula == NULL){
       printf("Erro: espaco insuficiente!!");

    }else{

        nova_celula->item = valor; //insere o valor na nova c�lula
        nova_celula->ant = topo;  //prox recebe o valor da c�lula de baixo

        topo= nova_celula;  //topo aponta para o endere�o da nova c�lula

        contador++;

    }
}
int desempilha( ){

    int valor;

    pilha *temp; //variavel temporaria para n�o perder o topo

    if(pilha_vazia()){

       printf("\n Pilha vazia!!!\n");
       return 0;

    }else{

        valor =topo->item; //variavel recebe o valor do item
        temp = topo;       //variavel temporaria recebe o topo para n�o perder
        topo=topo->ant;   //topo aponta pra celula de baixo

        free(temp);

        contador--; //tira o valor do contador
        return valor; //diz que deu tudo certo

    }
}

int elemento_topo(){//obtem o elemento topo da pilha

    int valor;

    if(pilha_vazia()){

       printf("Pilha vazia!!!");
       return 0;

     }else{
        valor=topo->item;
        return valor;
     }
}

bool finaliza_pilha(){

    pilha *temp;     //variavel temporaria

     if(pilha_vazia()){ //so limpa a pilha se tiver elementos para limpar

       printf("Pilha vazia!!!");
       return false;

     }else{

        while(topo !=NULL){
            temp=topo; //variavel temporaria recebe topo para n�o perder o topo
            temp->ant = NULL;  //Desconecta a c�lula de cima da de baixo //celula aponta pra null
            topo=topo->ant;

            free(temp);

        }

        contador=0;
        return true;
     }
}

void mostra_pilha()
{
    pilha *aux;
    aux = topo;
    printf("\nPilha: ");

    while(aux!=NULL)
    {
        printf(" | %d \n", aux->item);
        aux = aux->ant;
    }
    system("pause");
}


///ARVORE



typedef struct {
    int dado;
    struct no *esq;
    struct no *dir;
}no;
no  *raiz;
no  *atual;
no  *ant; //anterior
no *noTest;




void cria_arvore(){

   raiz=NULL;
   atual=NULL;
   ant=NULL;
   //return raiz;

}
int arvore_vazia(no *raiz){

  if(raiz == NULL){
    return 1;

  }else{

    return 0;
  }
}
int insere_arvore(int valor){

   //cria um novo no
   no *novo =(no*)malloc(sizeof(no));

   novo->dado=valor;
   novo->dir =NULL;
   novo->esq =NULL;


    if(raiz == NULL){ //se for a primeira vez entra no caso especial

      raiz=novo;
      return 1;

    }else{

        atual=raiz;
        ant=atual;

        //enquanto n�o chegar no n� folha
        while(atual!=NULL){

                //valor maior que a raiz
                if(valor>atual->dado){
                    ant=atual;
                    atual=atual->dir;

                //valor menor que a raiz
                }else{
                    ant=atual;
                    atual=atual->esq;
                }
         }


            //insere como filho desse no folha
            if(valor > ant->dado){
                ant->dir = novo;
            }else{
                ant->esq = novo;
            }
            return 1;
       }
     }
void pre_ordem(no *raiz){

    if(raiz == NULL){

        //printf("\n NULL");
        //"return" sem valor, simplesmente retorna o controle
        //para a fun��o que chamou a fun��o corrente.
        //Nenhum valor de retorno � passado, ou seja,
        //o valor de retorno � indefinido.
        return;

    }else if(raiz != NULL){

     printf("%d \n ", raiz->dado);
     pre_ordem(raiz->esq);
     pre_ordem(raiz->dir);

    }
}

//esquerda raiz direita
void em_ordem(no *raiz){

    if(raiz ==NULL){
        return;
    }else if(raiz != NULL){

      em_ordem(raiz->esq);
      printf("%d \n", raiz->dado);
      em_ordem(raiz->dir);
    }
}

//esquerda direita raiz
void pos_ordem(no *raiz){

    if(raiz ==NULL){
        return;
    }else if(raiz != NULL){

     pos_ordem(raiz->esq);
     pos_ordem(raiz->dir);
     printf("%d \n", raiz->dado);

    }

}
no* remove_atual(no *atual){


  no *no1, *no2;

  //nos folhas com 1 filho
  if(atual->esq==NULL){ //se n�o existir filho a esquerda

     no2=atual->dir; //aponta para o filho da direita
     free(atual);
     return no2;

  }

//---------no com dois filhos ----------------------------
//-----procura filho mais a direita da sub-arvore a esquerda
  no1=atual;
  no2=atual->esq;

  while(no2->dir != NULL){

    no1=no2;
    no2=no2->dir;
  }
//---------------copia mais a direita da subarvore da esquerda para o lugar do no removido

  if(no1 != atual){

    no1->dir = no2->esq;
    no2->esq = atual->esq;
  }

  no2->dir = atual ->dir;
  free(atual);
  return no2;


}

//------------------------------------busca no a ser removido na arvore--------------------

int remove_no(no *raiz, int valor){

  if(raiz==NULL) return 0;

  ant = NULL;
  atual = raiz;

      while(atual != NULL){

        //busca o n� a ser removido e trata o lado da remo��o
        if( valor == atual->dado){

            if(atual == raiz){ //se o valor est� na raiz

               raiz = remove_atual(atual); //chama a fun��o e remove a raiz

            }else{

                    if(ant->dir == atual){ //verifica se o no a ser retirado est� a direita

                      ant->dir = remove_atual(atual);

                    }else{

                      ant->esq = remove_atual(atual);

                    }
            }

           return 1;
         }
    //continua andando na arvore a procura do n� a ser removido
         ant=atual;
         if(valor>atual->dado){

            atual=atual->dir;
         }else{

            atual=atual->esq;
         }

      }//fim while
}

///FILA

typedef struct {
    int dado;
    struct fila *prox;
}fila;

fila *inicio;
fila *fim;

void inicializa_fila(){
 inicio=NULL;
 fim=NULL;
}
int fila_vazia(){

  if(inicio==NULL){

    return 1;
  }else {
   return 0;
  }

}
void enfileirar(int valor){
  //cria um novo no
  fila *novo=(fila*)malloc(sizeof(fila));

  novo->dado =valor;
  novo->prox=NULL;

  if(inicio==NULL){ //primeira vez

    inicio=novo; //inicio aponta pro novo no

  }else{
    fim->prox=novo;// Novo n� ser� apontado pelo �ltimo n� da fila
  }

   fim=novo;    //Ajusta-se o fim
}

void mostra_fila()
{
    fila *aux;
    aux =inicio;

	printf("\n Fila : ");
	while(aux != NULL)
	{
		printf(" | %d ", aux->dado);
		aux = aux->prox; //incrementa o ponteiro
	}
}

int menu()
{
    int opc;
    system("CLS");
    printf("\n\t~~~~ MENU ~~~~");
    printf("\n1 - Inserir na pilha.");
    printf("\n2 - Mostrar pilha.");
    printf("\n3 - Desempilhar pilha na arvore.");
    printf("\n4 - Mostrar arvore.");
    printf("\n5 - Inserir valor da ARVORE na FILA.");
    printf("\n6 - Mostrar fila.");
    printf("\n0 - Sair.\n->");
    scanf("%d",&opc);
    while(opc<0 || opc>6)
    {
        printf("\nOPC invalido, digite novamente....\n");
        scanf("%d",&opc);
    }
    return opc;

}
int main()
{
    cria_arvore();
    inicializa_fila();
    int opc,xP,bole,test,MostraArvore,DesemArvore,ArvoFila;

    opc = menu();
    while(opc!=0)
    {
        switch(opc)
        {
        case 1:
            system("CLS");

            insere_pilha();
            opc = menu();
            break;
        case 2:
            mostra_pilha();
            opc = menu();
            break;
        case 3:
            system("CLS");
            printf("\nDeseja Inserir pilha na arvore: ");
            printf("\n1 - Sim");
            printf("\n0 - Nao\n->");
            scanf("%d",&bole);
            while(bole<0 || bole>1)
            {
                printf("\nOPC invalida, digite novamente\n->");
                scanf("%d",&bole);
            }
            if(bole ==1 )
            {
                while(topo != NULL)
                {
                    DesemArvore = desempilha();
                    insere_arvore(DesemArvore);
                }
            }
            opc = menu();
            break;
        case 4:
            system("CLS");
            printf("\nMostrar Arvore: ");
            printf("\n1 - Pre Ordem");
            printf("\n2 - Em Ordem");
            printf("\n3 - POS Ordem");
            scanf("%d",&MostraArvore);
            while(MostraArvore>3 || MostraArvore<1)
            {
                printf("\nOPC invalida, digite novamente\n->");
                scanf("%d",&MostraArvore);
            }
            if(MostraArvore == 1 )
            {
                pre_ordem(raiz);
            }
            if(MostraArvore ==2 )
            {
                em_ordem(raiz);
            }
            if(MostraArvore == 3)
            {
                pos_ordem(raiz);
            }
            printf("\n\n");
            system("pause");
            opc = menu();

            break;
        case 5:
            system("CLS");
            printf("\n\tDigite o valor da arvore a ser inserido na fila:\n->");
            scanf("%d",&ArvoFila);

            int y = remove_no(raiz,ArvoFila);

            enfileirar(ArvoFila);
            opc = menu();
            break;
        case 6:
            mostra_fila();
            printf("\n\n");
            system("pause");
            opc = menu();
            break;
        }
    }
    printf("\n\n\tAINDA FUNFANDO \n");
    return 0;
}
