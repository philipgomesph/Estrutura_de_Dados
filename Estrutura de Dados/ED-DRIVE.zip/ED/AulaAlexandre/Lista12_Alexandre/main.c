#include <stdio.h>
#include <stdlib.h>
#include <string.h>
///ALUNO: Philipe Matheus Gomes.
typedef struct
{
    int cpf;
    struct fila *prox;
}fila;
fila *inicio;
fila *fim;

void inicializaFila()
{
    inicio= NULL;
    fim = NULL;
}
int filaVazia()
{
    if(inicio==NULL)
    {
        return 1;

    }else
    {
        return 0;
    }
}
void enfileira(int cpf)
{
   fila *novo;
   novo = (fila*)malloc(sizeof(fila));
   novo->cpf=cpf;
   novo->prox=NULL;

   if(inicio==NULL)
   {
       inicio=novo;
       fim=novo;
   }else
   {
       fim->prox=novo;
   }
   fim=novo;
}
int removeFila()
{
    if(filaVazia()==1)
    {
        printf("\nNao eh possivel remover\n");
        printf("\nFila vazia...\n");
        system("pause");
        return 0;
    }else
    {
       fila *aux;
       aux = inicio;
        int y;
        y=aux->cpf;
        inicio=inicio->prox;
        free(aux);
        return(y);
    }
}
void mostraFila()
{
    fila *aux;
    aux = inicio;
    printf("\nClientes na Fila: ");
    while(aux!=NULL)
    {
        printf("\n | %d", aux->cpf);
        aux = aux->prox;
    }
}

int menu()
{
    system("CLS");
    int opc;
    printf("\n ~~~~  MENU  ~~~~");
    printf("\n1 - Inserir usuario a fila.");
    printf("\n2 - Remover ususario da fila.");
    printf("\n3 - Mostrar quantos ingressos foram vendidos.");
    printf("\n0 - Sair.\n->");
    scanf("%d",&opc);
    while(opc<0 || opc>3)
    {
        printf("\nOPC invalida, digite novamente....\n->");
        scanf("%d",&opc);
    }
    return opc;
}

int main()
{
    int opc,valor,qtd;
    inicializaFila();
    qtd = 0;
    opc = menu();
    while(opc!=0)
    {
        switch(opc)
        {
        case 1:
            system("CLS");
            printf("\nInforme o cpf: ");
            scanf("%d",&valor);
            enfileira(valor);
            opc = menu();
            break;
        case 2:
            system("CLS");
            int x;
            x = removeFila();
            if(x!=0)
            {
                qtd++;
                printf("\nProximo cliente para a compra: %d\n\n",x);
                system("pause");
            }

            opc = menu();
            break;
        case 3:
            mostraFila();
            printf("\n\nIngressos vendidos: %d\n\n\n",qtd);
            system("pause");
            opc = menu();
            break;
        }
    }
    system("CLS");
    printf("\n\n\tObrigado por usar nosso sistema, ate logo...\n");
    return 0;
}
