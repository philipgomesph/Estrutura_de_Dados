#include <stdio.h>
#include <stdlib.h>
typedef struct {
    int dado;
    struct fila *prox;
}fila;

fila *inicio;
fila *fim;

void inicializa_fila(){
 inicio=NULL;
 fim=NULL;
}


int fila_vazia(){

  if(inicio==NULL){

    return 1;
  }else {
   return 0;
  }

}


void enfileirar(int valor){
  //cria um novo no
  fila *novo=(fila*)malloc(sizeof(fila));

  novo->dado =valor;
  novo->prox=NULL;

  if(inicio==NULL){ //primeira vez

    inicio=novo; //inicio aponta pro novo no

  }else{
    fim->prox=novo;// Novo n� ser� apontado pelo �ltimo n� da fila
  }

   fim=novo;    //Ajusta-se o fim
}




int remove_fila( )
{

  if(fila_vazia()==1){

    printf("Nao e possivel remover\n");
    printf("Fila Vazia!!\n");
    return 0;

  }else{


    fila *aux;     //ponteiro auxiliar
	aux=inicio;  //aponta para o n� inicial


	//essa vari�vel � necess�rio porque ao dar free no no esse valor ser� perdido
	int y;   //vari�vel que recebe o valor de retorno
	y =aux->dado; //passa o valor da struc para a vari�vel


	inicio=inicio->prox; //aponta para a proxima posi��o

	free(aux); //liberado.

    return(y);

  }

}


void mostra_fila()
{
    fila *aux;
    aux =inicio;

	printf("\n Fila : ");
	while(aux != NULL)
	{
		printf(" | %d ", aux->dado);
		aux = aux->prox; //incrementa o ponteiro
	}
}

typedef struct {
    int dado;
    struct no *esq;
    struct no *dir;
}no;
no  *raiz;
no  *atual;
no  *ant;


void cria_arvore(){

   raiz=NULL;
   atual=NULL;
   ant=NULL;
   //return raiz;

}
int arvore_vazia(no *raiz){

  if(raiz == NULL){
    return 1;

  }else{

    return 0;
  }
}
int insere_arvore(int valor){

   //cria um novo no
   no *novo =(no*)malloc(sizeof(no));

   novo->dado=valor;
   novo->dir =NULL;
   novo->esq =NULL;


    if(raiz == NULL){ //se for a primeira vez entra no caso especial

      raiz=novo;
      return 1;

    }else{

        atual=raiz;
        ant=atual;

        //enquanto n�o chegar no n� folha
        while(atual!=NULL){

                //valor maior que a raiz
                if(valor>atual->dado){
                    ant=atual;
                    atual=atual->dir;

                //valor menor que a raiz
                }else{
                    ant=atual;
                    atual=atual->esq;
                }
         }


            //insere como filho desse no folha
            if(valor > ant->dado){
                ant->dir = novo;
            }else{
                ant->esq = novo;
            }
            return 1;
       }
     }
void em_ordem(no *raiz){

    if(raiz ==NULL){
        return;
    }else if(raiz != NULL){

      em_ordem(raiz->esq);
      printf("%d \n", raiz->dado);
      em_ordem(raiz->dir);
    }
}
void pre_ordem(no *raiz){

    if(raiz == NULL){

        return;
    }else if(raiz != NULL){

     printf("%d \n ", raiz->dado);
     pre_ordem(raiz->esq);
     pre_ordem(raiz->dir);

    }
}

void pos_ordem(no *raiz){

    if(raiz ==NULL){
        return;
    }else if(raiz != NULL){

     pos_ordem(raiz->esq);
     pos_ordem(raiz->dir);
     printf("%d \n", raiz->dado);

    }

}







int verifica_Inserir_Arvore()
{
    int veri;
    system("CLS");
    printf("\n\tDeseja desinfileirar na arvore: ");
    printf("\n1 - Sim");
    printf("\n0 - Nao\n->");
    scanf("%d",&veri);
    while(veri<0 || veri>1)
    {
        printf("\nOPC invalida, digite novamente...\n->");
        scanf("%d",&veri);
    }
    return veri;
}
int menu()
{
    int opc;
    system("CLS");
    printf("\n\t~~~ MENU  ~~~");
    printf("\n1 - Enfileirar");
    printf("\n2 - Desenfileirar");
    printf("\n3 - Mostrar Fila");
    printf("\n4 - Inserir fila na Arvore");
    printf("\n5 - Mostrar arvore EM ORDEM");
    printf("\n6 - Mostrar arvore PRE ORDEM");
    printf("\n7 - Mostrar arovore POS ORDEM");
    printf("\n0 - Sair.\n->");
    scanf("%d",&opc);
    while(opc<0 || opc>7)
    {
        printf("\nOPC invalida, digite novamente...\n->");
        scanf("%d",&opc);
    }
    return opc;
}
int main()
{
    int opc,valor,veri,valorA;
    opc = menu();
    while(opc!=0)
    {
        switch(opc)
        {
            case 1:
            system("CLS");
            printf("\n\tInforme o valor a ser inserido na Fila:\n->");
            scanf("%d",&valor);
            enfileirar(valor);
            opc = menu();
                break;
            case 2:
                valor = remove_fila();
                printf("VALOR REMOVIDO\n");
                printf("%d",valor);
                printf("\n");
                system("pause");
                opc = menu();
                break;
            case 3:
                mostra_fila();
                printf("\n");
                system("pause");
                opc = menu();
                break;
            case 4:
                veri = verifica_Inserir_Arvore();
                if(veri==1)
                {
                    while(inicio != NULL)
                    {
                        valorA = remove_fila();
                        valorA = insere_arvore(valorA);

                    }
                    opc = menu();
                }else
                {
                    opc = menu();
                }
                break;
            case 5:
                em_ordem(raiz);
                printf("\n");
                system("pause");
                opc = menu();
                break;
            case 6:
                pre_ordem(raiz);
                printf("\n");
                system("pause");
                opc = menu();
                break;
            case 7:
                pos_ordem(raiz);
                printf("\n");
                system("pause");
                opc = menu();
                break;
        }
    }

    printf("\n\n\tAINDA FUNFANDO\n");
    return 0;
}
