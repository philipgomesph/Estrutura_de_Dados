#include <stdio.h>
#include <stdlib.h>



int main()
{
    int *v1;
    int MAX;
    MAX = 2;
    v1 = (int*)calloc(sizeof(int),MAX);
    //*v1 = 100;
    //printf("\n%d",*v1);
    receber(v1,MAX);
    mostrar(v1,MAX);
    multiplica(v1,MAX);
    free(v1);
    printf("\n\n\t AINDA FUNFANDO\n");
    return 0;
}


void multiplica(int *v1, int MAX)
{
    int i;
    int *v2;
    v2= (int*)calloc(sizeof(int),MAX);

    for(i=0; i<MAX; i++)
    {
        printf("\nDigite os valores para multiplicar");
        scanf("\n%d",&v2[i]);
    }
    for(i=0;i<MAX;i++)
    {
        v1[i]= v1[i]*v2[i];
        printf("\nOs valores das multiplicacoes sao : %d",v1[i]);
    }
    free(v2);

}

void receber(int *v1, int MAX)
{
    int i;
    for(i=0; i<MAX;i++)
    {
        printf("\nDigite os valores do vetor: ");
        scanf("%d", &v1[i]);
    }
}

void mostrar(int *v1, int MAX)
{
    int i;
    for(i = 0; i<MAX; i++)
    {
        printf("\nOs valores do vetor sao: ");
        printf("\n%d", v1[i]);
    }
}
