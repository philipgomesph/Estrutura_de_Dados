#include <stdio.h>
#include <stdlib.h>
#include "pontH.h"
int main()
{
    struct aluno a[2];
    int opc;
    int i=0;

    opc= menu();



    while(opc!= 0)
    {

        switch(opc)
        {
        case 1:
            while(i<2)
            {
                system("CLS");
                printf("Digite o nome do aluno %d\n",i);
                fflush(stdin);
                gets(a[i].nome);
                printf("\nDigite a nota da p1 do aluno %d\n",i);
                scanf("\n%d",&a[i].p1);
                printf("\nDigite a nota da p2 do aluno %d\n",i);
                scanf("\n%d",&a[i].p2);
                printf("\nDigite a nota da p3 do aluno %d\n",i);
                scanf("\n%d",&a[i].p3);
                i++;
            }
            opc= menu();
            break;
        case 2:
            break;

        }
    }
    printf("\n\tAINDA FUNFANDO\n");
    return 0;
}


int menu()
{
    int opc;
    system("CLS");
    printf("\n\n\tSistema Escolar\n");
    printf("\n1 - Inserir alunos");
    printf("\n2 - Mostrar alunos");
    printf("\n0 - Sair.");
    scanf("\n%d",&opc);
    while(opc <0 || opc>2)
    {
        printf("\n\nOPC invalida, digite novamente\n");
        scanf("\n%d",&opc);
    }

    return opc;

}



struct aluno
{
    char nome[30];
    int p1,p2,p3;

};

