#include <stdio.h>
#include <stdlib.h>
#define max 2
int pilha[max];
int topo;
int aux;
int inicio, fim;
int fila[max];

int inicia_pilha(){
    topo=-1;
}

int pilha_vazia(){
    if(topo==-1){
        return 1; //pilha vazia
    }else{
        return 0; //pilha cheia
    }
}

int pilha_cheia(){
    if(topo==max-1){
        return 1; //pilha cheia
    }else{
        return 0; //pilha com espa�o
    }
}
void insere_pilha(int valor){
    if(pilha_cheia()==1){
       printf("\n Erro:Pilha cheia!!! \n ");
       system("pause");

    }else{
        topo++;
        pilha[topo]=valor;
        printf("\n Valor inserido [%d]: %d",topo,pilha[topo]);
    }
}

int remove_pilha( ){
    if(pilha_vazia()==1){
        printf("\n Erro: pilha vazia!!! \n");
    }else{
      aux=pilha[topo];
      topo--;
      return aux;


    }
}
void inicia_fila(){
    inicio=0;
    fim=-1;
}

int fila_vazia(){
  if(inicio>fim){

    return 1; //fila vazia

  }else{

    return 0;
  }

}

int fila_cheia(){
  if(fim>=max-1){
   return 1;

  }else{
      return 0;
      }
}


void insere_fila(int valor){
    if(fila_cheia()==1){
      printf("fila cheia!!!");
      exit(1);

    }else{
        fim++;
        fila[fim]=valor;
        printf("\n\n valor inserido com sucesso!! \n\n");

    }
}

int retira_fila(int valor){
   if(fila_vazia()==1){
    printf("Pilha vazia!!!\n");
    return 0;

   }else{
     valor=fila[inicio];
     inicio++;
     return valor;
   }

}
int tamanho(){

 return (fim-inicio)+1;

}
int menu()
{
    system("CLS");
    int opc;
    printf("\n\n1 - Digite os dados da pilha.");
    printf("\n2 - Desempilhar um dado da pilha na fila.");
    printf("\n0 - Sair.\n->");
    scanf("%d",&opc);
    while(opc<0 || opc>2)
    {
        printf("\nOPC invalida, digite novamente...\n->");
        scanf("%d",&opc);
    }
    return opc;
}


int main()
{
    int opc,valor,valor2;
    inicia_pilha();
    opc = menu();
    while(opc!=0)
    {
        switch(opc)
        {
        case 1:
            system("CLS");
            printf("\nDigite o valor a ser inserido na pilha: \n");
            scanf("%d",&valor);
            insere_pilha(valor);
            opc = menu();
            break;
        case 2:
            insere_fila(remove_pilha());
            opc = menu();
            break;
        }
    }
    printf("\n\n\t  Obrigado por usar nosso sistema...\n");
    return 0;
}
