#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int dado;
    struct no *prox;
    struct nov *ant;
}no;
no *inicio;
no *fim;

void incializaLista()
{
    inicio=NULL;
    fim=NULL;

}
int listaVazia()
{
    if(inicio==NULL)
    {
        return 1;
    }else
    {
        return 0 ;
    }
}

void inserir_inicio_listaVazia(int valor)
{
    no *novo=(no*)malloc(sizeof(no));
    novo->dado=valor;
    novo->prox=NULL;
    novo->ant=NULL;

    if(inicio==NULL)
    {
        inicio=novo;
        fim=novo;
    }else
    {
        inicio->ant=novo;
        novo->prox=inicio;
        inicio=novo;

    }
}
void inserirFim(int valor)
{
    no *novo=(no*)malloc(sizeof(no));
    novo->dado=valor;
    novo->prox=NULL;
    novo->ant=NULL;

    fim->prox=novo;
    novo->ant=fim;
    fim=novo;
}
void inserirLista(int valor)
{
    no *aux;
    no *aux2;
    aux = inicio;
    if(listaVazia()==1)
    {
        inserir_inicio_listaVazia(valor);

    }else
    {
         while(valor>aux->dado)
         {
            if(aux->prox==NULL)
            {
                inserirFim(valor);
            }

                aux2 = aux;
                aux=aux->prox;
         }



    }


}
void mostra_lista()
{
    no *aux;
    aux =inicio;

  if(listaVazia()==1){
    printf("\n Lista Vazia ");

  }else{

	printf("\n Lista : ");
	while(aux != NULL)
	{
		printf(" | %d ", aux->dado);
		aux = aux->prox; //incrementa o ponteiro
	}
  }
}

int pegaValor()
{
    int valor;
    system("CLS");
    printf("\nDigite o valor desejado");
    scanf("%d",&valor);
    return valor;
}
int menu()
{
    int opc;
    system("CLS");
    printf("\n  ~~~~  MENU  ~~~~");
    printf("\n1 - Inserir numero");
    printf("\n2 - Remover numero");
    printf("\n3 - Mostrar Lista");
    printf("\n0 - Sair.\n->");
    scanf("%d",&opc);
    while(opc<0 || opc>3)
    {
        printf("\nOpc invalida, digite novamente....");
        scanf("%d",&opc);
    }
    return opc;
}

int main()
{
    int opc,valor;

    opc = menu();
    while(opc!=0)
    {
        switch(opc)
        {
        case 1:
            valor = pegaValor();
            inserirLista(valor);
            opc = menu();
            break;
        case 2:
            opc = menu();
            break;

        case 3:
            mostra_lista();
            printf("\n\n");
            system("pause");
            opc = menu();
            break;
        }
    }
    printf("\n\n\tAINDA FUNFANDO \n\n");
    return 0;
}
