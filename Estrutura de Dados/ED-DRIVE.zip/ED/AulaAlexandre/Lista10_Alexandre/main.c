///Aluno: Philipe Matheus Gomes
#include <stdio.h>
#include <stdlib.h>
int menu()
{
    int opc;
    system("CLS");
    printf("\n\n\t ~~~~  MENU  ~~~~");
    printf("\n1 - Receber valor para primeira Pilha.");
    printf("\n2 - Receber valor para segunda Pilha.");
    printf("\n3 - Comparar se sao iguais.");
    //printf("\n4 - Mostras pilhas.");
    printf("\n0 - Sair.\n=>");
    scanf("%d",&opc);
    while(opc<0 || opc>4)
    {
        printf("\nOpc invalida, digite novamente\n=>");
        scanf("%d",&opc);
    }
    return opc;
}


///varaiveis globais
typedef struct{
    int item;
    struct pilha *prox;
}pilha;

/*void inicia(pilha *pilha)
{
    pilha->prox=NULL;
}
*/

pilha *inserir_pilha(pilha *p)
{
    pilha *aux;
    pilha *novo;
    int temp;
    novo = (pilha*)malloc(sizeof(pilha));
    system("CLS");
    printf("\nDIGITE O CONTEUDO A SER INSERIDO NA PILHA:\n=>");
    scanf("%d",&novo->item);
    novo->prox=NULL;
    //DECIDINDO ONDE COLOCAR
    aux = p;
    if(aux== NULL)
    {
        p = novo;
    }
    else
    {
        while(aux->prox !=NULL)
        {
            aux = aux->prox;
        }
        aux->prox = novo;
    }
    return(p);
}
void compara_pilha(pilha *p, pilha *p2)
{
    system("CLS");
    int i;
    int j;
    pilha *aux;
    aux = p;
    if(p == NULL)
    {
        printf("\nPilha 1, vazia.. \n");
        system("PAUSE");
    }
    else
    {
        if(p2==NULL)
        {
            printf("\nPilha 2, vazia..\n");
            system("PAUSE");
        }
        else
        {
            while(aux!=NULL)
            {
                if(aux->item == p2->item)
                {
                    p2=p2->prox;

                }
                else
                {
                    printf("\nListas sao diferentes !!\n");
                    system("PAUSE");
                    aux->prox = NULL;
                }
                aux=aux->prox;
                printf("\nPilhas iguais...\n");
                system("PAUSE");
            }
        }
    }
}

int main()
{
    int opc;
    struct pilha *p;
    struct pilha *p2;
    p= NULL;
    p2=NULL;
    opc = menu();
    while(opc!=0)
    {
            switch(opc)
        {
            case 1:
                p = inserir_pilha(p);
                opc = menu();
                break;
            case 2:
                p2 = inserir_pilha(p2);
                opc = menu();
                break;
            case 3:
                compara_pilha(p,p2);
                opc = menu();
                break;
            case 4:
                break;
        }
    }
    printf("\n\n\tAINDA FUNFANDO\n");
    return 0;
}
