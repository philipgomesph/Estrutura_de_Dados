#include <stdio.h>
#include <stdlib.h>

struct produto
{
    char nome[30];
    double preco;
    int qtd;
    struct produto *prox;
};

int menu()
{
    int opc;
    system("CLS");
    printf("\n\t~~MENU~~");
    printf("\n1 - Inserir");
    printf("\n2 - Mostrar pelo preco");
    printf("\n3 - Mostrar pela quantidade");
    printf("\n0 - Sair.\n");
    scanf("%d",&opc);

    while(opc<0 || opc>3)
    {
        printf("\nOPC invalida, digite novamente...\n");
        scanf("%d",&opc);
    }

    return opc;
}

struct produto *inserir(struct produto *lista)
{
    //Variaveis da funcao
    struct produto *aux;
    struct produto *novo;

    //Variaveis Temporaria
    char nomeTemp[30];
    double precoTemp;
    int qtdTemp;

    system("CLS");
    printf("\nDigite o nome do produto:\n");
    fflush(stdin);
    gets(nomeTemp);

    printf("\nDigite o preco:\n");
    scanf("%d",&precoTemp);
    while(precoTemp<0)
    {
        printf("\nPreco invalido digite novamente:\n");
        scanf("%d",&precoTemp);
    }

    printf("\nDigite a quantidade do produto:\n");
    scanf("%d",&qtdTemp);
    while(qtdTemp<1)
    {
        printf("\nQuantidade informada invalida, digite novamente:\n");
        scanf("%d",&qtdTemp);
    }

    novo = (struct produto*) malloc(sizeof(struct produto));

    strcpy(novo->nome, nomeTemp);
    novo->preco = precoTemp;
    novo->qtd = qtdTemp;
    novo->prox = NULL;

    aux = lista;
    if(aux==NULL)
    {
        lista = novo;
    }
    else
    {
        while(aux->prox!=NULL)
        {
            aux = aux->prox;
        }
        aux->prox = novo;
    }
    return(lista);
};
void mostrarPreco(lista)
{
    struct produto *aux;
    aux = lista;
    printf("\n\tProdutos da lista por preco\n");
    if(lista == NULL)
    {
        printf("\nLista vazia...\n\n");
    }


}





int main()
{

    ///variaveis globais
    int opc;

    ///variaveis de estrutura
    struct produto *lista;
    lista = NULL;

    ///menu
    opc = menu();

    ///desenvolvimento
    while(opc!=0)
    {
        switch(opc)
        {
        case 1:
            lista = inserir(lista);
            opc = menu();
            break;
        case 2:
            mostrarPreco(lista);
            break;
        case 3:
            break;
        }
    }

    printf("\n\n\n\tAINDA FUNFANDO!!!!\n\n");
    return 0;
}
