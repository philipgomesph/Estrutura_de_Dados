#include "pontoH.h"

struct funcionarios *inserir(struct funcionarios *lista)
{
    system("CLS");

    //VARIAVEIS DA FUN�AO
    char nomeTemp[30];
    int matriculaTemp;
    float salarioTemp;
    struct funcionarios *aux;
    struct funcionarios *novo;


    printf("\n\tDigite os dados dos funcionarios");
    printf("\nNOME: ");
    fflush(stdin);
    gets(nomeTemp);
    printf("\nMATRICULA: ");
    scanf("%d",&matriculaTemp);
    while((verificaMatricula(matriculaTemp, lista)) == 0)
    {
        printf("\nNumero de matricula ja em uso, digite novamente.\n");
        scanf("%d", &matriculaTemp);
    }

    printf("\nSALARIO: ");
    scanf("%f",&salarioTemp);


    //validadndo dados para entrar
    while(salarioTemp<0)
    {
        printf("\n\nSalario invalido, digite novamente\n");
        scanf("%d",&salarioTemp);
    }


    novo = (struct funcionarios*)malloc(sizeof(struct funcionarios));

    strcpy(novo->nome,nomeTemp);
    novo->matricula = matriculaTemp;
    novo->salario = salarioTemp;
    novo->prox = NULL;

    //INSERINDO NO FINAL
    aux = lista;

    if(aux == NULL)
    {
        lista = novo;
    }
    else
    {
        while(aux->prox != NULL)
        {
            aux = aux->prox;
        }
        aux->prox = novo;
    }


    return (lista);
};

void mostrar(struct funcionarios *lista)
{
    struct funcionarios *aux;

    aux = lista;

    if(aux == NULL)
    {
        printf("\n\nLista vazia\n\n");
    }
    else
    {
        while(aux != NULL)
        {
            printf("\nNOME: %s", aux->nome);
            printf("\nMATRICULA: %d", aux->matricula);
            printf("\nSALARIO: %.2f\n", aux->salario);
            aux= aux->prox;
        }

    }
    system("pause");
}
void mostrarMaiorNome(struct funcionarios *lista)
{
    char maiorNome[30];
    struct funcionarios *aux;
    aux = lista;
    strcpy(maiorNome, lista->nome);

    /*if(aux == NULL)
    {
        printf("\n\nLista vazia");
        return 0;
    }*/

    while(aux != NULL)
    {
        if(strlen(aux->nome) > strlen(maiorNome))
        {
            strcpy(maiorNome, aux->nome);
        }
        aux = aux->prox;
    }
    char *last = strrchr(maiorNome, ' ');

    if(last !=NULL)
    {
        system("CLS");
        printf("\nFuncionario com maior nome: \n ");
        printf("%s\n\n", last+1);
    }

    system("pause");

}


int verificaMatricula(int matriculaTemp,struct funcionarios *lista)
{
    struct funcionarios *aux;
    aux = lista;
    if(aux == NULL)
    {
        return 1;
    }
    else
    {
        while(aux != NULL)
        {
            if(matriculaTemp == aux->matricula)
            {
                return 0;
            }
            aux = aux->prox;
        }
        return 1;
    }
}




