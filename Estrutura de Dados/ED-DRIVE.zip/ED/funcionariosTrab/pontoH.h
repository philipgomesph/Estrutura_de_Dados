#ifndef PONTOH_H_INCLUDED
#define PONTOH_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct funcionarios
{
    char nome[30];
    int matricula;
    float salario;
    struct funcionarios *prox;
};

struct funcionarios *inserir(struct funcionarios *lista);
void mostrar(struct funcionarios *lista);
int verificaMatricula(int matriculaTemp,struct funcionarios *lista);
void mostrarMaiorNome(struct funcionarios *lista);


#endif // PONTOH_H_INCLUDED
