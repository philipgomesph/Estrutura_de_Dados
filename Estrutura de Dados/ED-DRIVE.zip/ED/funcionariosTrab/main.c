#include <stdio.h>
#include <stdlib.h>
#include "pontoH.h"
int main()
{
    //VARIAVEIS GERAIS
    int opc;

    //VARIAVEIS DE ESTRUTURA
    struct funcionarios *lista;
    lista = NULL;,



    opc = menu();
    while(opc!=0)
    {
        switch(opc)
        {
        case 1:
            lista = inserir(lista);
            opc = menu();
            break;
        case 2:
            mostrar(lista);
            opc = menu();
            break;
        case 3:
            mostrarMaiorNome(lista);
            opc = menu();
            break;
        }
    }


    printf("\n\t Finalizando... \n\n");
    return 0;
}
int menu()
{
    int opc;

    system("CLS");
    printf("\n\t  MENU ");
    printf("\n1 - Inserir Funcionarios");
    printf("\n2 - Mostrar funcionarios");
    printf("\n3 - Mostrar funcionario com maior nome");
    printf("\n0 - Sair.\n");
    scanf("%d", &opc);

    while(opc<0 || opc>3)
    {
        printf("\n\nOp�ao invalida, digite novamente");
        scanf("%d",&opc);
    }
    return(opc);
}
