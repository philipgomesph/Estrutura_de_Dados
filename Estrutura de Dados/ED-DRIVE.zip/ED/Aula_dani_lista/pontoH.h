#ifndef PONTOH_H_INCLUDED
#define PONTOH_H_INCLUDED


///ESTRUTURA DO NO DA LISTA
///  NUMA LISTA TEMOS :
/// - criar uma lista
/// - inserir elemento
/// - remover elemento
/// - alterar elemento
/// - consultar elemento

struct no
{
    int info;
    struct no *prox;

};typedef struct no NO;

NO* cria_lista();        ///RETORNA UM PONTEIRO (NESSE CASO

NO* insere(NO *inicio, int valor);


#endif // PONTOH_H_INCLUDED
