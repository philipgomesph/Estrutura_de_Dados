#include <stdio.h>
#include <stdlib.h>
#include "pontoH.h"
#include <string.h>
#include <math.h>

int main()
{
    printf("\n\n\n   AINDA FUNCIONANDO   \n\n");
    return 0;
}
