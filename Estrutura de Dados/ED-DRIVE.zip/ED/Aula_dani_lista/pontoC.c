#include "pontoH.h"
#include <stdio.h>
#include <stdlib.h>

///   NUMA LISTA TEMOS :
/// - criar uma lista
/// - inserir elemento
/// - remover elemento
/// - alterar elemento
/// - consultar elemento

NO* cria_lista()
{
    NO *inicio = null;   ///Criando o ponteiro inicio q aponta pro primeiro elemento da lista
    return inicio;       ///retorna esse ponteiro.
}

NO* insere(NO *inicio, int valor)
{
    NO *novo;    ///Criei um novo NO chamado novo(tem q ser ponteiro).


    novo = (NO*)malloc((sizeof(struct no));   ///Abri espa�o para ele

    novo->info = valor;    ///Iniciando as variaveis dele.
    novo->prox = inicio;

    inicio = novo; ///Fazendo o inicio aportar pro novo.


}
