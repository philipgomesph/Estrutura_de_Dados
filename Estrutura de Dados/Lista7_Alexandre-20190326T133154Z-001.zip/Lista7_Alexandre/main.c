#include <stdio.h>
#include <stdlib.h>

int menu()
{
    int opc;
    system("CLS");
    printf("\n1 - Inserir Pessoas");
    printf("\n2 - Mostrar Pessoas");
    printf("\n3 - Inseir novas pessoa");
    printf("\n0 - Sair.\n");
    scanf("%d",&opc);
    while(opc<0 || opc>3)
    {
        printf("\nOPC invalida, digite novamente: \n");
        scanf("%d",&opc);
    }

    return (opc);
}

void inserir(int *p,int tam)
{


    int i;
    for(i=0; i<tam;i++)
    {
        printf("\nDigite um numero desejado");
        scanf("\n%d", &p[i]);
    }
}
void mostrar(int*p,int tam)
{
    int i;
    for(i=0;i<tam;i++)
    {
        printf("\nValor na posicao %d:  ",i);
        printf("%d",p[i]);
    }
    printf("\n\n");
    system("pause");
}
int realocar(int *p, int tam)
{
    system("CLS");
    int i,aumenta;
    printf("\nDeseja aumentar quantas pessoas: \n");
    scanf("\n%d\n",&aumenta);
    i = tam;


    p = (int*)realloc(p,aumenta*sizeof(int));
    if(p == NULL)
    {
        printf("\nERRO de memoria");
    }
    for(i=tam;i<aumenta+tam;i++)
    {
        printf("\nDigite o novo numero na posicao %d :\n", i);
        scanf("%d",&p[i]);
    }

    tam = tam+aumenta;
    return tam;
}

int main()
{
    ///VARIAVEIS
    int opc,tam;
    int *p;
    p = (int*)calloc(sizeof(int),tam);

    printf("\n\n\tInforme o tamanho do cadastro\n->");
    scanf("\n%d",&tam);



    opc = menu();
    while(opc!=0)
    {
        switch(opc)
        {
        case 1:

            inserir(p,tam);
            opc=menu();

            break;
        case 2:
            mostrar(p,tam);
            printf("\n");


            opc=menu();

            break;
        case 3:
            realocar(p,tam);
            opc=menu();
            break;
        }
    }


    printf("\n\n\tAINDA FUNFANDO\n");
    return 0;
}
